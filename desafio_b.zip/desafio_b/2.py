import requests
import mysql.connector
banco=mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="desafio_b"
)
meucursor = banco.cursor()

print("Verificando endereço")
nome = input("Digite seu nome e sobrenome: ")
cep = input("Digite CEP: ")
link = f'https://viacep.com.br/ws/{cep}/json'
requisicao = requests.get(link)
endereco = requisicao.json()
cep1 = endereco ['cep']
logradouro = endereco ['logradouro']
complemento = endereco ['complemento']
bairro = endereco ['bairro']
localidade = endereco ['localidade']
uf = endereco ['uf']
if len(cep) != 8:
    print("CEP invalido")
    exit()
consulta = requests.get(f'https://viacep.com.br/ws/{cep}/json')


meucursor = banco.cursor()
sql= 'INSERT INTO enderecos (nome, logradouro, complemento, cep, bairro, localidade, uf) values (%s,%s,%s,%s,%s,%s,%s)'
data= (nome, logradouro, complemento, cep, bairro, localidade, uf)

meucursor.execute(sql,data)
banco.commit()


