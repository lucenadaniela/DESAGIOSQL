import mysql.connector

banco=mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="desafio_b"
)
meucursor = banco.cursor()
print('MENU')
escolha = 0
while escolha != 3:
  escolha = int(input("ESCOLHA: 1 - CONSULTAR/ 2 - INSERIR/ 3 - SAIR: "))
  if escolha == 1:
     pesquisa = "select * from alunos;"
     meucursor.execute(pesquisa)
     # fetchall recebe tudo da pesquisa e retorna atraves de uma tupla
     resultado = meucursor.fetchall()
     for x in resultado:
      print(x)

  elif escolha == 2:
    nome1=input("Digite nome: ")
    telefone1=int(input("Digite telefone:"))
    sql = "insert into alunos (nome,telefone) values (%s, %s)"
    data = (nome1,telefone1)
    meucursor.execute(sql,data)
    banco.commit()




  elif escolha == 3:
    print("SAIR")
    meucursor.close()
    banco.close()
